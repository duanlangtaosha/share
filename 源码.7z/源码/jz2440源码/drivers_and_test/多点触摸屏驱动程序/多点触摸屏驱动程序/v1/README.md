
Demo driver for multi touch panel, it is only a Framework, for weidongshan's android video tutorial.  
  
You can't compile it, it is only a Framework.   
  
It uses a i2c Multi-Touch Panel Controller.  









